﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace FarmManagementForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // Метод для загрузки любой таблицы
        private void LoadTable(string tableName)
        {
            string connectionString = System.Configuration.ConfigurationManager
                .ConnectionStrings["FarmManagementForms.Properties.Settings.BDFarmManagementConnectionString"]
                .ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = $"SELECT * FROM {tableName}";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dataGridView1.DataSource = table;

                    // Меняем заголовок формы
                    this.Text = $"Фермерское хозяйство - {tableName}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки таблицы {tableName}: " + ex.Message);
                }
            }
        }

        // Кнопка 1: Работники
        private void button1_Click(object sender, EventArgs e)
        {
            LoadTable("Employees");
        }

        // Кнопка 2: Работы
        private void button2_Click(object sender, EventArgs e)
        {
            LoadTable("Works");
        }

        // Кнопка 3: Назначения
        private void button3_Click(object sender, EventArgs e)
        {
            LoadTable("Assignments");
        }
    }
}